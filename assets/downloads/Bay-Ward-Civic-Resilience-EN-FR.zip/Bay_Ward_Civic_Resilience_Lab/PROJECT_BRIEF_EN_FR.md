# Bay Ward: Four Challenges, One Community
## Independent bilingual simulation proposal / Proposition de simulation bilingue indépendante

### English
**Audience:** Bay Ward residents, community associations, small businesses, municipal service teams, and the office of Councillor Theresa Kavanagh.

**Learning objective:** In a 15–25-minute scenario, participants identify relevant City processes, select safe and accessible stakeholder responses, and evaluate what international practices can and cannot be transferred to Bay Ward.

**Four missions:** Flooding and resilience; construction and access; safe streets; inclusive community recreation.

**Learning design:** Four role perspectives, eight scored decisions, optional risk-repair branches, nine distinct evidence-linked cases and an action-oriented summary. No registration or real-case submissions; simulated incidents do not substitute for 3-1-1 or Engage Ottawa.

**Special Japan evidence checkpoint:** Distinguishes a built, movable flood wall in Arashiyama from a separate recycling trial that manufactured construction barricades from recovered plastics. A material is not flood-certified merely because it has been recycled.

**Proposed municipal pilot (subject to invitation and approval):** Have residents, ward staff, accessibility specialists, flood engineers and recreation service staff test a neutral version. Collect anonymous usability feedback, not personal resident complaints. Discuss site suitability and procedural accuracy before any official use.

**Independent status:** Not a City of Ottawa product, Council consultation, endorsement or policy evaluation.

### Français
**Public :** Résidents du quartier Baie, associations, petites entreprises, services municipaux et bureau de la conseillère Theresa Kavanagh.

**Objectif :** En 15 à 25 minutes, reconnaître les procédures municipales, choisir des réponses sûres et accessibles, et distinguer les pratiques internationales qui peuvent être adaptées de celles qui exigent des études locales.

**Quatre missions :** Inondations; chantiers et accès; sécurité routière; loisirs inclusifs.

**Conception :** Quatre rôles, huit décisions notées, branches de correction, neuf études de cas avec sources et bilan orienté vers l’action. Aucun compte requis; les incidents du jeu ne sont pas transmis à la Ville.

**Point de vigilance sur le Japon :** Ne pas confondre le mur anti-inondation mobile d’Arashiyama et l'étude distincte sur des barrières de chantier en plastique recyclé. Une preuve de recyclage n'est pas une homologation hydraulique.

**Pilote éventuel :** Évaluer le prototype avec les résidents, les équipes de quartier, des spécialistes en accessibilité et des ingénieurs, sous réserve d’une invitation et des validations nécessaires.

**Statut :** Initiative pédagogique indépendante, sans approbation municipale présumée.
