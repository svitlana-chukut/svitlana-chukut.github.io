# QA & Accessibility Review — Bay Ward Civic Resilience Lab

Test date: November 18, 2026 (local date for the authoring session; content references events through 2026).

## Automated functional browser checks
- Chromium: 8 role × language completion paths tested (en/R1, en/R2, en/R3, en/R4, fr/R1, fr/R2, fr/R3, fr/R4).
- Each optimal completion returns **100 / 100**.
- First risk selection and successful recovery path returned **90 / 100** (7 × 12.5 + 0 + 2.5).
- French / English toggle during a decision and feedback preserves game state.
- Responsive overflow checked for widths **320, 375, 768, 870, 1024, 1280 and 1440 px**, no horizontal scrolling from layout.
- Nine unique case cards are linked to specific challenges: 3 flood, 2 construction, 2 safety, 2 recreation.
- No external scripts or network requests are required for the game. Sources open only on explicit link click.
- Basic browser JavaScript execution showed no page errors in tested paths.

## Accessibility design features (implemented)
- Semantic buttons, headings, landmarks; skip link and visible keyboard focus.
- Accessible language toggle with document language change EN/FR.
- High contrast option, larger text toggle, reduced-motion CSS support.
- At least 48px minimum primary/button interaction height in most states.
- Choice explanation text, live announcements for scene transitions.
- Responsive two-column and one-column layouts.
- No account, personal data, tracking pixels or automatic online submission.

## NOT YET VERIFIED
- Full WCAG 2.2 AA conformance, screen reader audits (NVDA, JAWS, VoiceOver),
  real user testing, zoom 400%/reflow audit, full keyboard-only audit with assistive technology,
  touch target audit for every link, audit of all available language translations.
- Do not claim municipal City of Ottawa approval or conformance certification.
- Ottawa's public website Accessibility Policy specifies WCAG 2.0 AA for City-owned/controlled public-facing websites.
  This independent game aims to be designed consistently but is not an audited City product.

## Sources checked
- City Ottawa Accessibility Policy: https://ottawa.ca/en/city-hall/your-city-government/policies-and-administrative-structure/accessibility-policy
- City Ottawa Public Engagement Strategy: https://ottawa.ca/en/city-hall/public-engagement/how-were-engaging-you/public-engagement-strategy-and-workbook
- Ottawa extreme weather memo: https://ottawa.ca/en/city-hall/open-transparent-and-accountable-government/public-disclosure/memoranda-issued-members-council/memoranda-issued-infrastructure-and-water-services/memo-july-1-extreme-weather-event-july-11-2026
- Scientific paper Arashiyama: https://www.jstage.jst.go.jp/article/jscejj/81/5/81_24-00105/_article/-char/en
- Recycled-plastic construction barricades: https://www.jstage.jst.go.jp/article/jsmcwm/36/0/36_201/_article/-char/en
