# Case application notes / Notes sur l'application des études de cas

## Methodological note / Note méthodologique

**EN:** Each entry describes a documented practice and a *proposed transfer*, not an existing or approved Bay Ward project. Engineering, procurement, accessibility, privacy and budget rules must be checked before any deployment.

**FR :** Chaque entrée présente une pratique documentée et une *adaptation proposée*, non un projet déjà approuvé dans le quartier Baie. Il faut vérifier les exigences techniques, d’approvisionnement, d’accessibilité, de vie privée et de budget avant tout déploiement.

### Important Japan evidence check / Vérification des preuves japonaises

- **Arashiyama / 嵐山 (Kyoto):** Nakamura et al., JSCE 2025, DOI 10.2208/jscejj.24-00105 describes a movable **flood** barrier completed in 2022 and consensus-building to preserve the riverfront landscape. **It does not establish that the barrier was made of recycled plastic.**
- **Recycled plastic / Plastique recyclé:** Fukatsu et al., 2025, DOI 10.14912/jsmcwm.36.0_201 describes a production demonstration of **5,000 construction-work barricades**, with **86% material yield**. The publication does **not** validate those barricades for hydrostatic loads, water tightness or flood deployment.
- **Transfer / Adaptation:** In Ottawa, any recycled-plastic water barrier idea requires site-specific independent civil/structural/hydraulic review, environmental and material testing, and authorization before deployment. No player choice recommends emergency use of uncertified materials.

## 1. Floods & resilience / Inondations et résilience

### C1 · Copenhagen: Cloudburst streets / Copenhague : des rues pour gérer les pluies extrêmes

**EN — Evidence:** Combine surface routes for stormwater, sewer upgrades and retention spaces. Street design can deliver more than drainage alone.
**EN — Transfer:** Map Bay Ward's overland flow routes with City engineers; test multifunctional retention options and publish maintenance responsibilities.
**EN — Stakeholders:** City water/infrastructure staff + residents
**EN — Indicator:** Fewer repeat flood hotspots; audited performance in design storms
**EN — Caution:** A surface project cannot alone remedy sewer backup inside homes.

**FR — Constat :** Combiner des parcours de ruissellement en surface, la mise à niveau des égouts et les zones de rétention. La voirie peut aussi servir d’espace public.
**FR — Application :** Cartographier les parcours de ruissellement dans le quartier Baie avec les ingénieurs; tester des espaces multifonctionnels et publier les responsabilités d’entretien.
**FR — Parties prenantes :** Services d’eau et d’infrastructure + résidents
**FR — Indicateur :** Moins de points de débordement récurrents; performance vérifiée pour les pluies de référence
**FR — Limite :** Les aménagements de surface ne règlent pas, à eux seuls, les refoulements d'égout dans les maisons.
**Source:** https://www.c40.org/case-studies/c40-good-practice-guides-copenhagen-cloudburst-management-plan/

### J1 · Japan: Arashiyama movable flood barrier / Japon : barrière anti-inondation mobile d’Arashiyama

**EN — Evidence:** Kyoto-area engineers chose a movable flood wall after extensive resident consultation and full-scale design checks to preserve riverfront views.
**EN — Transfer:** Study whether any specific Bay Ward site has a hydraulic case for a demountable barrier; use mock-ups, public consultation and an emergency deployment plan.
**EN — Stakeholders:** Certified engineers + City + residents and emergency teams
**EN — Indicator:** Verified hydraulic capacity and deployment drills; accessibility and landscape checks
**EN — Caution:** The cited study does NOT say the Arashiyama flood barrier was made from recycled plastic. River overtopping differs from basement sewer surcharge.

**FR — Constat :** Près de Kyoto, des ingénieurs ont retenu un mur mobile après consultations et essais en grandeur réelle afin de préserver la vue sur les berges.
**FR — Application :** Étudier si un site précis du quartier Baie justifie une barrière amovible; prévoir maquettes, consultation et procédure de déploiement d’urgence.
**FR — Parties prenantes :** Ingénieurs qualifiés + Ville + résidents et équipes d’urgence
**FR — Indicateur :** Capacité hydraulique vérifiée et exercices de déploiement; contrôles d'accessibilité et d'intégration
**FR — Limite :** L'étude citée ne dit PAS que la barrière d’Arashiyama est faite de plastique recyclé. Le débordement fluvial diffère du refoulement d’égout.
**Source:** https://www.jstage.jst.go.jp/article/jscejj/81/5/81_24-00105/_article/-char/en

### J2 · Japan: recycled-plastic construction barricades / Japon : barrières de chantier en plastique recyclé

**EN — Evidence:** A separate Japanese recycling demonstration made 5,000 construction barricades from recovered plastic, reporting 86% mass yield. They were traffic/work-zone barricades, not tested flood barriers.
**EN — Transfer:** Treat recycled polymer as a candidate MATERIAL only: request independent watertightness, structural, UV, freeze–thaw and anchorage testing before any Ottawa flood pilot.
**EN — Stakeholders:** City engineering + materials labs + procurement + community
**EN — Indicator:** Pass/fail engineering test matrix and lifecycle assessment before procurement
**EN — Caution:** Do not present a construction barricade as waterproof flood protection or install an untested barrier in an emergency.

**FR — Constat :** Une autre démonstration japonaise a fabriqué 5 000 barrières de chantier à partir de plastique récupéré (rendement massique de 86 %). Il ne s'agissait pas de barrières anti-crue testées.
**FR — Application :** Considérer le polymère recyclé comme MATÉRIAU possible seulement : exiger des essais indépendants d'étanchéité, de structure, d'UV, de gel-dégel et d'ancrage avant tout projet pilote.
**FR — Parties prenantes :** Ingénierie municipale + laboratoires + approvisionnement + communauté
**FR — Indicateur :** Matrice d'essais réussite/échec et analyse du cycle de vie avant achat
**FR — Limite :** Ne pas présenter une barrière de chantier comme protection étanche ni installer un dispositif non testé en situation d'urgence.
**Source:** https://www.jstage.jst.go.jp/article/jsmcwm/36/0/36_201/_article/-char/en
## 2. Construction & access / Travaux et accès

### C2 · Toronto: construction hubs / Toronto : pôles de coordination des chantiers

**EN — Evidence:** Toronto coordinates overlapping construction, pedestrian routing and safety through a designated Construction Hub program.
**EN — Transfer:** Pilot a Bay Ward 'single disruption calendar' involving utilities, transit contractors, businesses and accessibility reviewers.
**EN — Stakeholders:** City construction coordinators + contractors + businesses
**EN — Indicator:** Advance-notice reliability, accessible detour uptime, complaint response time
**EN — Caution:** Requires City/contractor authority; councillor offices cannot unilaterally change closures.

**FR — Constat :** Toronto coordonne les chantiers simultanés, les parcours piétonniers et la sécurité dans ses zones de travaux concentrés.
**FR — Application :** Tester un calendrier unique des perturbations associant services publics, entrepreneurs du transport, commerces et spécialistes de l’accessibilité.
**FR — Parties prenantes :** Coordonnateurs municipaux + entrepreneurs + commerces
**FR — Indicateur :** Fiabilité des avis anticipés, disponibilité des détours accessibles et délai de réponse
**FR — Limite :** La Ville et les entrepreneurs doivent autoriser les changements; le bureau du conseiller ne peut décider seul.
**Source:** https://www.toronto.ca/services-payments/streets-parking-transportation/road-safety/construction-hubs/

### C3 · London: lane-rental incentives / Londres : incitatifs pour les chantiers routiers

**EN — Evidence:** Lane-rental schemes incentivize road work at less disruptive times and coordination across contractors.
**EN — Transfer:** Compare Ottawa's existing powers and contracts with a non-financial first step: coordinated windows, common notices and documented change controls.
**EN — Stakeholders:** City legal/transportation staff + contractors
**EN — Indicator:** Hours of avoidable lane closure; missed notice deadlines
**EN — Caution:** London's charging scheme is not automatically authorized in Ottawa.

**FR — Constat :** Les mécanismes de redevance incitent à réaliser les travaux aux heures les moins perturbatrices et à coordonner les entrepreneurs.
**FR — Application :** Comparer les pouvoirs et contrats existants d’Ottawa; commencer sans nouvelles redevances par des fenêtres coordonnées, avis communs et suivi des changements.
**FR — Parties prenantes :** Services juridiques et transports + entrepreneurs
**FR — Indicateur :** Heures de fermeture évitables; avis transmis en retard
**FR — Limite :** Les redevances londoniennes ne sont pas automatiquement autorisées à Ottawa.
**Source:** https://www.gov.uk/government/publications/street-works-lane-rental/lane-rental-schemes-guidance-for-english-highway-authorities
## 3. Safe streets & mobility / Rues sûres et mobilité

### C4 · Montréal: Vision Zero / Montréal : Vision Zéro

**EN — Evidence:** A 2025–2027 action plan uses system-wide road-safety measures rather than relying only on changing individual behaviour.
**EN — Transfer:** Use Ottawa's traffic-calming criteria to assess a high-risk Bay Ward route; collect near-miss and accessibility observations before selecting treatments.
**EN — Stakeholders:** Traffic engineers + school/community groups + accessibility advisors
**EN — Indicator:** Measured speeds, conflicts and safe access after intervention
**EN — Caution:** Safety measures need site-specific approval; do not infer crash statistics from anecdotes.

**FR — Constat :** Le plan 2025–2027 prévoit des mesures systémiques de sécurité routière, au-delà de la sensibilisation individuelle.
**FR — Application :** Appliquer les critères d'apaisement d’Ottawa à un trajet à risque du quartier; documenter quasi-accidents et obstacles avant de choisir les mesures.
**FR — Parties prenantes :** Ingénieurs de circulation + groupes scolaires et citoyens + conseillers en accessibilité
**FR — Indicateur :** Vitesses, conflits de circulation et accès sécuritaire après intervention
**FR — Limite :** Les mesures doivent être approuvées pour chaque site; les témoignages ne remplacent pas les données d’accidents.
**Source:** https://montreal.ca/en/articles/vision-zero-getting-around-safely-foot-bike-and-car-14584

### C5 · Helsinki: a year with zero road deaths / Helsinki : une année sans décès routier

**EN — Evidence:** Helsinki reported no traffic fatalities over a 12-month period, within a longer Vision Zero effort involving lower speeds and street design.
**EN — Transfer:** Set a measurable safe-streets improvement plan for school and transit access, then publish progress rather than promising zero incidents immediately.
**EN — Stakeholders:** Transportation services + public health + community
**EN — Indicator:** Before/after speed and conflict indicators with accessible route audits
**EN — Caution:** The historical 12-month result is not a guarantee that identical measures will yield the same outcome locally.

**FR — Constat :** Helsinki a déclaré zéro décès routier sur douze mois, dans le cadre d’un effort Vision Zéro de longue durée associant vitesses réduites et aménagement.
**FR — Application :** Définir un plan mesurable pour les trajets scolaires et vers le transport en commun, puis publier les progrès sans promettre zéro incident immédiat.
**FR — Parties prenantes :** Services de transport + santé publique + communauté
**FR — Indicateur :** Vitesses et conflits avant/après, plus audits des trajets accessibles
**FR — Limite :** Le résultat observé sur douze mois ne garantit pas le même effet à Ottawa.
**Source:** https://urban-mobility-observatory.transport.ec.europa.eu/news-events/news/helsinki-records-zero-road-deaths-over-past-year-2025-08-22_en
## 4. Recreation & shared space / Loisirs et espaces partagés

### C6 · Helsinki: OmaStadi participation / Helsinki : participation OmaStadi

**EN — Evidence:** Residents propose ideas, co-develop viable projects and see which proposals move into implementation.
**EN — Transfer:** Publish a Bay Ward options-and-trade-offs board for Grandeur Park, including costs, accessibility and a 'you said / we did' update.
**EN — Stakeholders:** Recreation staff + resident groups + councillor's office
**EN — Indicator:** Diverse participation, published decisions and explanation of rejected ideas
**EN — Caution:** Do not claim Bay Ward has a participatory budget unless one is formally approved.

**FR — Constat :** Les résidents proposent des idées, codéveloppent des projets réalisables et suivent leur mise en œuvre.
**FR — Application :** Publier un tableau des options et compromis pour le parc Grandeur, avec coûts, accessibilité et retour « vous avez dit / nous avons fait ».
**FR — Parties prenantes :** Services des loisirs + associations de résidents + bureau du conseiller
**FR — Indicateur :** Participation diversifiée, décisions publiées et raisons des options écartées
**FR — Limite :** Ne pas prétendre qu'un budget participatif existe dans le quartier sans décision officielle.
**Source:** https://omastadi.hel.fi/pages/omastadi?locale=en

### C7 · Vancouver: VanPlay equity lens / Vancouver : équité selon VanPlay

**EN — Evidence:** VanPlay identifies inequities in access and prioritizes investment where service gaps are greatest.
**EN — Transfer:** Compare children's, seniors', adaptive-sport and low-income access needs before recommending the future Belltown Dome/Grandeur Park concept.
**EN — Stakeholders:** Parks and recreation + community organizations + accessibility reviewers
**EN — Indicator:** Who can use the new space, at what cost, in which seasons and hours
**EN — Caution:** Equity analysis supplements, rather than replaces, engineering and budget assessments.

**FR — Constat :** VanPlay repère les inégalités d'accès et priorise les investissements dans les secteurs où les besoins sont les plus grands.
**FR — Application :** Comparer les besoins des enfants, aînés, sports adaptés et ménages à faible revenu avant de recommander un concept pour Belltown Dome et le parc Grandeur.
**FR — Parties prenantes :** Parcs et loisirs + organismes communautaires + spécialistes de l’accessibilité
**FR — Indicateur :** Qui peut utiliser le nouvel espace, à quel coût, en quelles saisons et à quelles heures
**FR — Limite :** L'analyse d'équité complète les études techniques et budgétaires, sans les remplacer.
**Source:** https://vancouver.ca/parks-recreation-culture/vanplay-parks-and-recreation-strategy.aspx